---
title: Another Note on A blogdown Tutorial
author: Yihui Xie
date: '2017-06-14'
categories:
  - Example
tags:
  - Tutorial
slug: another-note
---

I just discovered [an awesome tutorial](https://apreshill.rbind.io/post/up-and-running-with-blogdown/) on **blogdown** written by Alison. I have to admit this is _the_ best **blogdown** tutorial I have seen so far.

![](https://apreshill.rbind.io/img/posts/2017-06-12-up-and-running-with-blogdown/blogdown-signpost-4.png)
